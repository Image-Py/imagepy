from imagepy.core.engine import Filter, Simple
from imagepy.ipyalg import watershed
import numpy as np
import cv2

def combine(img):
    h,w = img.shape
    l, r = img[:,:w//2], img[:,w//2:]
    return np.hstack((l.T[::-1,:], r.T[:,::-1]))

class Combine(Simple):
    title = 'Re Combine'
    note = ['8-bit']
    
    #process
    def run(self, ips, imgs, para = None):
        for i in range(len(imgs)):
            imgs[i] = combine(imgs[i])
            self.progress(i, len(imgs))
        ips.set_imgs(imgs)

class Dark(Filter):
    title = 'Dark Little'
    note = ['all', 'auto_msk', 'auto_snap']

    def run(self, ips, snap, img, para = None):
        np.multiply(snap, 0.95, out=img, casting='unsafe')
        img += 1

class DOG(Filter):
    title = 'Fast DOG'
    note = ['all', 'auto_msk', 'auto_snap', 'preview']

    #parameter
    para = {'sigma':0}
    view = [(float, (0,30), 1,  'sigma', 'sigma', 'pix')]

    #process
    def run(self, ips, snap, img, para = None):
        l = int(para['sigma']*3)*2+1
        cv2.GaussianBlur(snap, (l, l), para['sigma'], dst=img)
        msk = img<snap
        img-=snap
        img[msk] = 0

class Watershed(Filter):
    title = 'Watershed Surface'
    note = ['8-bit', 'auto_snap', 'not_channel', 'preview']

    #process
    def run(self, ips, snap, img, para = None):
        markers = img*0
        markers[[0,-1]] = [[1],[2]]
        mark = watershed(img, markers, line=True, conn=1)
        img[:] = (mark==0) * 255

plgs = [Combine, Dark, '-', DOG, Watershed]